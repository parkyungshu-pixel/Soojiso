const listEl = document.getElementById("list");
const countEl = document.getElementById("count");
const statusEl = document.getElementById("status");
const saveBtn = document.getElementById("save");
const clearBtn = document.getElementById("clear");

function render(items) {
  listEl.value = items.join("\n");
  countEl.textContent = `${items.length} item${items.length === 1 ? "" : "s"}`;
}

function parse(text) {
  return text
    .split("\n")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

chrome.storage.local.get(["items"], ({ items }) => {
  render(Array.isArray(items) ? items : []);
});

saveBtn.addEventListener("click", () => {
  const items = parse(listEl.value);
  chrome.storage.local.set({ items }, () => {
    render(items);
    statusEl.textContent = "Saved ✓";
    statusEl.className = "ok";
    setTimeout(() => (statusEl.textContent = ""), 1500);
  });
});

clearBtn.addEventListener("click", () => {
  chrome.storage.local.set({ items: [] }, () => {
    render([]);
    statusEl.textContent = "Cleared";
    setTimeout(() => (statusEl.textContent = ""), 1500);
  });
});
