(function () {
  if (window.__autofillListInjected) return;
  window.__autofillListInjected = true;

  // Avoid injecting in iframes to reduce duplicates
  if (window.top !== window.self) return;

  const wrap = document.createElement("div");
  wrap.id = "autofill-list-fab-wrap";
  wrap.innerHTML = `
    <button id="autofill-list-fab" type="button" title="AutoFill next item">⚡ Fill</button>
    <button id="autofill-list-hide" type="button" title="Hide">×</button>
  `;
  document.documentElement.appendChild(wrap);

  const fab = wrap.querySelector("#autofill-list-fab");
  const hideBtn = wrap.querySelector("#autofill-list-hide");

  hideBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    wrap.style.display = "none";
  });

  function isVisible(el) {
    if (!el) return false;
    if (el.disabled || el.readOnly) return false;
    if (el.offsetParent === null && getComputedStyle(el).position !== "fixed") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function findTarget() {
    const selector =
      'input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=checkbox]):not([type=radio]):not([type=file]):not([type=image]):not([type=reset]), textarea';
    const candidates = Array.from(document.querySelectorAll(selector));
    return candidates.find(isVisible) || null;
  }

  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
  }

  fab.addEventListener("click", (e) => {
    e.stopPropagation();
    chrome.storage.local.get(["items"], ({ items }) => {
      const list = Array.isArray(items) ? items : [];
      if (list.length === 0) {
        alert("Empty list na — magdagdag ka muna sa extension popup.");
        return;
      }
      const target = findTarget();
      if (!target) {
        alert("Walang nakitang input field sa page na ito.");
        return;
      }
      const value = list[0];
      target.focus();
      setNativeValue(target, value);
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));

      const next = list.slice(1);
      chrome.storage.local.set({ items: next }, () => {
        // Brief visual feedback
        const original = fab.textContent;
        fab.textContent = `✓ ${next.length} left`;
        setTimeout(() => (fab.textContent = original), 1200);
      });
    });
  });
})();
